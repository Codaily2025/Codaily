package com.codaily.codereview;

import com.codaily.codereview.dto.ChecklistEvaluationRequestDto;
import com.codaily.codereview.dto.FeatureChecklistRequestDto;
import com.codaily.codereview.dto.FeatureChecklistResponseDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@RequiredArgsConstructor
public class GptRequestClient {

    private final RestTemplate restTemplate;

    private static final String CHECKLIST_API_URL = "http://localhost:8000/api/generate-checklist";

    public FeatureChecklistResponseDto generateChecklist(FeatureChecklistRequestDto requestDto) {
        return restTemplate.postForObject(
                CHECKLIST_API_URL,
                requestDto,
                FeatureChecklistResponseDto.class
        );
    }
}
