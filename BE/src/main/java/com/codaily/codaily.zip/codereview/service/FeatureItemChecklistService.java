package com.codaily.codereview.service;

import com.codaily.codereview.dto.ChecklistEvaluationResponseDto;
import com.codaily.codereview.dto.FeatureChecklistRequestDto;
import com.codaily.codereview.entity.FeatureItemChecklist;

import java.util.List;
import java.util.Map;

public interface FeatureItemChecklistService {

    List<FeatureItemChecklist> getChecklistByFeatureId(Long featureId);

    FeatureItemChecklist addChecklistItem(Long featureId, String item, String description);

    void saveEvaluation(Long featureId, Map<String, Boolean> evaluationMap);

    public void generateChecklistForRequirementSpec(Long requirementSpecId);
    public void generateChecklistForFeatureList(FeatureChecklistRequestDto request);


}