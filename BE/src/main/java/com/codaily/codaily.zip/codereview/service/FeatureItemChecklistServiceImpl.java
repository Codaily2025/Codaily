package com.codaily.codereview.service;

import com.codaily.codereview.GptRequestClient;
import com.codaily.codereview.dto.ChecklistEvaluationResponseDto;
import com.codaily.codereview.dto.FeatureChecklistFeatureDto;
import com.codaily.codereview.dto.FeatureChecklistRequestDto;
import com.codaily.codereview.dto.FeatureChecklistResponseDto;
import com.codaily.project.entity.FeatureItem;
import com.codaily.codereview.entity.FeatureItemChecklist;
import com.codaily.codereview.repository.FeatureItemChecklistRepository;
import com.codaily.project.repository.FeatureItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FeatureItemChecklistServiceImpl implements FeatureItemChecklistService {

    private final FeatureItemChecklistRepository checklistRepository;
    private final FeatureItemRepository featureItemRepository;
    private final GptRequestClient gptRequestClient;

    @Override
    public List<FeatureItemChecklist> getChecklistByFeatureId(Long featureId) {
        return checklistRepository.findByFeatureItem_FeatureId(featureId);
    }

    @Override
    public FeatureItemChecklist addChecklistItem(Long featureId, String item, String description) {
        FeatureItem feature = featureItemRepository.findById(featureId)
                .orElseThrow(() -> new IllegalArgumentException("해당 기능이 존재하지 않습니다"));

        FeatureItemChecklist checklist = FeatureItemChecklist.builder()
                .featureItem(feature)
                .item(item)
                .description(description)
                .build();

        return checklistRepository.save(checklist);
    }

    @Override
    @Transactional
    public void saveEvaluation(Long featureId, Map<String, Boolean> evaluationMap) {
        for (Map.Entry<String, Boolean> entry : evaluationMap.entrySet()) {
            String item = entry.getKey();
            boolean isDone = entry.getValue();

            checklistRepository.findByFeatureItem_FeatureIdAndItem(featureId, item)
                    .ifPresentOrElse(
                            checklist -> checklist.updateDone(isDone),
                            () -> {
                                // 기존에 없는 항목(extraImplemented)인 경우 새로 생성
                                FeatureItem featureItem = featureItemRepository.findById(featureId)
                                        .orElseThrow(() -> new IllegalArgumentException("해당 기능 없음: " + featureId));
                                FeatureItemChecklist newChecklist = FeatureItemChecklist.builder()
                                        .featureItem(featureItem)
                                        .item(item)
                                        .done(true)
                                        .build();
                                checklistRepository.save(newChecklist);
                            }
                    );
        }
    }

    @Override
    @Transactional
    public void generateChecklistForRequirementSpec(Long requirementSpecId) {
        // 1. 명세서에 속한 기능 목록 조회
        List<FeatureItem> features = featureItemRepository.findBySpecification_SpecId(requirementSpecId);

        // 2. GPT 요청 DTO로 변환
        List<FeatureChecklistFeatureDto> featureDtos = features.stream()
                .map(f -> FeatureChecklistFeatureDto.builder()
                        .featureId(f.getFeatureId())
                        .title(f.getTitle())
                        .description(f.getDescription())
                        .build())
                .toList();

        FeatureChecklistRequestDto requestDto = FeatureChecklistRequestDto.builder()
                .features(featureDtos)
                .build();

        // 3. GPT 요청 → 체크리스트 응답 받기
        FeatureChecklistResponseDto responseDto = gptRequestClient.generateChecklist(requestDto);

        // 4. 결과 저장 (featureId -> checklist 항목 리스트)
        responseDto.getChecklistMap().forEach((featureId, checklist) -> {
            FeatureItem featureItem = features.stream()
                    .filter(f -> f.getFeatureId().equals(featureId))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("해당 기능 ID 없음: " + featureId));

            List<FeatureItemChecklist> entities = checklist.stream()
                    .map(item -> FeatureItemChecklist.builder()
                            .featureItem(featureItem)
                            .item(item)
                            .done(false)
                            .build())
                    .toList();

            checklistRepository.saveAll(entities);
        });
    }

    @Override
    @Transactional
    public void generateChecklistForFeatureList(FeatureChecklistRequestDto request) {
        // 1. GPT 요청
        FeatureChecklistResponseDto response = gptRequestClient.generateChecklist(request);

        // 2. 응답 결과 순회: featureId -> checklist 항목들
        response.getChecklistMap().forEach((featureId, checklistItems) -> {
            FeatureItem feature = featureItemRepository.findById(featureId)
                    .orElseThrow(() -> new IllegalArgumentException("기능 ID 없음: " + featureId));

            List<FeatureItemChecklist> checklistEntities = checklistItems.stream()
                    .map(item -> FeatureItemChecklist.builder()
                            .featureItem(feature)
                            .item(item)
                            .done(false)
                            .build())
                    .toList();

            checklistRepository.saveAll(checklistEntities);
        });
    }


}
