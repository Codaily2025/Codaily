package com.codaily.common.git.service;

import com.codaily.codereview.dto.*;
import com.codaily.codereview.entity.CodeReviewItem;
import com.codaily.common.git.WebhookPayload;

import java.util.List;

public interface WebhookService {
    void handlePushEvent(WebhookPayload payload);

    public List<DiffFile> getDiffFilesFromCommit(WebhookPayload.Commit commit, String accessToken);

    public void sendDiffFilesToPython(Long projectId,
                                      Long commitId,
                                      List<DiffFile> diffFiles);

    public List<FullFile> getFullFilesFromCommit(String commitHash, Long projectId, Long userId);

    void sendChecklistEvaluationRequest(Long projectId, Long featureId, String featureName, List<FullFile> fullFiles, List<ChecklistItemDto> checklistItems);

//    public void sendCodeReviewItemRequest(ChecklistEvaluationResponseDto responseDto);

    public FeatureReviewResultDto sendCodeReviewItemRequest(ChecklistEvaluationResponseDto responseDto);
    public void sendCodeReviewSummaryRequest(Long featureId,
                                             String featureName,
                                             List<CodeReviewItem> reviewItems);

        //    public List<String> getChecklistByFeatureName(String featureName);

    }
