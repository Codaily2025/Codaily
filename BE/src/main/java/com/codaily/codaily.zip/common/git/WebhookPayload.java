package com.codaily.common.git;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

// 🔧 WebhookPayload.java 내부
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class WebhookPayload {

    private Repository repository;
    private Sender sender;
    private List<Commit> commits;

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Sender {
        private String login; // ✅ github account
        private Long id;
    }


    @Getter
    @NoArgsConstructor
    public static class Repository {
        private String name;
        private Owner owner;

        @Getter
        @NoArgsConstructor
        public static class Owner {
            private String name;
        }
    }


    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Commit {
        private String id;
        private String message;
        private Author author;
        private String url;
        private List<String> added;
        private List<String> modified;
        private List<String> removed;

        @Getter
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Author {
            private String name;
        }
    }
}
