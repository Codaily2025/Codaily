package com.codaily.common.gpt.handler;

import com.codaily.common.gpt.dispatcher.SseMessageDispatcher;
import com.codaily.common.gpt.service.ChatService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import reactor.core.publisher.Flux;

@Component
@RequiredArgsConstructor
public class ChatResponseStreamHandler {

    private final ChatService chatService;
    private final SseMessageDispatcher dispatcher;
    private final ObjectMapper objectMapper;

    public SseEmitter stream(String intent, String userId, String message, Long projectId, Long specId) {
        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);
        Flux<String> chatFlux = chatService.streamChat(intent, userId, message);

        chatFlux.subscribe(chunk -> {
            try {
                JsonNode root = objectMapper.readTree(chunk);
                MessageType type = MessageType.fromString(root.path("type").asText());
                JsonNode content = root.path("content");

                Object response = dispatcher.dispatch(type, content, projectId, specId);
                emitter.send(SseEmitter.event().data(objectMapper.writeValueAsString(response)));
            } catch (Exception e) {
                emitter.completeWithError(e);
            }
        }, emitter::completeWithError, emitter::complete);

        return emitter;
    }
}
