package com.codaily.project.service;

import com.codaily.auth.entity.User;
import com.codaily.project.dto.ProjectCreateRequest;
import com.codaily.project.dto.ProjectRepositoryResponse;
import com.codaily.project.entity.Project;

import java.util.List;
import java.util.Optional;

public interface ProjectService {
    void saveRepositoryForProject(Long projectId, String repoName, String repoUrl);

//    List<ProjectRepositoryResponse> getRepositoriesByProjectId(Long projectId);

    void deleteRepositoryById(Long repoId);

    void createProject(ProjectCreateRequest request, User user);

    Project findById(Long projectId);

    Optional<List<Project>> findAllByUserId(Long userId);
}
