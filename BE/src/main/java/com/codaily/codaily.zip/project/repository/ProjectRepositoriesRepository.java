package com.codaily.project.repository;
import com.codaily.project.entity.ProjectRepositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectRepositoriesRepository extends JpaRepository<ProjectRepositories, Long> {
//    boolean existsByProjectIdAndRepoUrl(Long projectId, String repoUrl);

//    List<ProjectRepositories> findByProjectId(Long projectId);

    Optional<ProjectRepositories> findByProject_ProjectId(Long projectId);

    Optional<ProjectRepositories> findByProject_ProjectIdInAndRepoName(List<Long> projectIds, String repoName);
}

